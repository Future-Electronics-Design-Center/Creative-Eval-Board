[ALIST]
Alists=
[CONE]
Cones=
[DRCSettings]
DRCMode=Minimal
[FIND]
Finder=0 1 0 0 0 0 0 0 0 0 0 0 0
StringToFind=*
CellType=
PaneName=
[FRAME]
Tools=HYDRA_netlist_viewer 
ActiveTool=HYDRA_netlist_viewer
PropertyList=WindowPlacement 
WindowPlacement=2 3 -1 -1 -1 -1 30 30 1182 626
[HIGHLIGHT GROUPS]
CurrentGroup=0
NumGroups=15
[HighlightGroup0]
Name=HighlightGroup0
Color=166 0 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup1]
Name=HighlightGroup1
Color=0 255 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup2]
Name=HighlightGroup2
Color=0 255 255
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup3]
Name=HighlightGroup3
Color=212 208 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup4]
Name=HighlightGroup4
Color=0 0 255
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup5]
Name=HighlightGroup5
Color=255 255 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup6]
Name=HighlightGroup6
Color=0 0 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup7]
Name=HighlightGroup7
Color=0 128 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup8]
Name=HighlightGroup8
Color=0 128 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup9]
Name=HighlightGroup9
Color=128 0 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup10]
Name=HighlightGroup10
Color=128 0 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup11]
Name=HighlightGroup11
Color=128 128 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup12]
Name=HighlightGroup12
Color=128 128 128
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup13]
Name=HighlightGroup13
Color=212 192 192
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HighlightGroup14]
Name=HighlightGroup14
Color=0 0 0
Macros=
Nets=
Regions=
Modules=-1 -1
Paths=
[HIERARCHY VIEW]
DockState=0
PropertyList=WindowPlacement 
WindowPlacement=0 1 -1 -1 -1 -1 1 -2 201 769
ActiveTab=0
[LOG VIEW]
DockState=0
PropertyList=WindowPlacement 
WindowPlacement=0 1 -1 -1 -1 -1 485 5 1920 155
[NETLIST VIEW]
NumWindow=1
[NETLIST VIEW1]
PropertyList=FIT LEVEL PAGE SPLIT ViewportExtents WindowPlacement 
FIT=0
LEVEL=AdlTop
PAGE=1
SPLIT=1
ViewportExtents=23903 33410 152249 88206
WindowPlacement=2 3 -1 -1 -9 -36 0 0 833 199
[SELECTION]
Macros=100,0
Nets=0
Regions=
Modules=-1 -1
Paths=
[WORLD VIEW]
DockState=0
PropertyList=WindowPlacement 
WindowPlacement=0 1 -1 -1 -1 -1 1 5 479 155
