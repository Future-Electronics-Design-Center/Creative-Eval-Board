/*******************************************************************************
 * Project     : PF_MiV_ADC_Demo
 * File        : MCP39x3.h
 *
 * Description : This file contains a definition for a basic ADC module
 *               interface.
 *
 * Created on  : Mar 15, 2018
 * Author      : Frederic.Vachon  
 *
 * (c) Copyright 2018 Future Electronics - Advanced Engineering Group 
 *     All rights reserved
 *
 * DISCLAIMER OF WARRANTY
 * All materials, information and services are provided “as-is” and “as-available”
 * for your use. Future Electronics disclaims all warranties of any kind, either
 * express or implied, including but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose, title, or non-infringement.
 * You acknowledge and agree that the reference designs and other such design
 * materials included herein are provided as an example only and that you will
 * exercise your own independent analysis and judgment in your use of these
 * materials. Future Electronics assumes no liability for your use of these
 * materials for your product designs.
 *
 * INDEMNIFICATION
 * You agree to indemnify, defend and hold Future Electronics and all of its
 * agents, directors, employees, information providers, licensors and licensees,
 * and affiliated companies (collectively, “Indemnified Parties”), harmless from
 * and against any and all liability and costs (including, without limitation,
 * attorneys’ fees and costs), incurred by the Indemnified Parties in connection
 * with any claim arising out of any breach by You of these Terms and Conditions 
 * of Use or any representations or warranties made by You herein. You will
 * cooperate as fully as reasonably required in Future Electronics’ defense of
 * any claim. Future Electronics reserves the right, at its own expense, to
 * assume the exclusive defense and control of any matter otherwise subject to
 * indemnification by You and You shall not in any event settle any matter
 * without the written consent of Future Electronics.
 *
 * LIMITATION OF LIABILITY
 * Under no circumstances shall Future Electronics, nor its agents, directors,
 * employees, information providers, licensors and licensee, and affiliated
 * companies be liable for any damages, including without limitation, direct,
 * indirect, incidental, special, punitive, consequential, or other damages
 * (including without limitation lost profits, lost revenues, or similar economic
 * loss), whether in contract, tort, or otherwise, arising out of the use or
 * inability to use the materials provided as a reference design, even if we
 * are advised of the possibility thereof, nor for any claim by a third party.
 ******************************************************************************/

#ifndef MCP39x3_H_
#define MCP39x3_H_

#include "cpu_types.h"

#ifndef NULL
#define NULL  (void*) 0
#endif

// -- Definitions ------------------------------------------------------------

// SPI Motorola Mode 0,0 frame definition
//  32 bits : Control byte, 24 bits Data

// Control byte definition
//	bit 7-6	Device address
//  bit 5-1 Register address
//	bit 0		Read/Write

// Device address definition
#define BASE_ADDR				0x40

// Read-only channel register (24 bits MSB first, left justified) ==============
#define READ_CH0				0x41
#define READ_CH1				0x43
#define READ_CH2				0x45
#define READ_CH3				0x47
#define READ_CH4				0x49
#define READ_CH5				0x4B

// Delta-sigma modulators output value (read-only) =============================
//	DEFAULT: 0x333333 (0011 0011 0011 0011 0011 0011)
//		bit 23-20 COMPn_CH5
//		bit 19-16 COMPn_CH4
//		bit 15-12 COMPn_CH3
//		bit 11-8  COMPn_CH2
//		bit 7-4   COMPn_CH1
//		bit 3-9   COMPn_CH0
#define READ_MOD				0x4D

// Phase delay config register =================================================
//	bit 23-16 CH4 relative to CH5 phase delay (2's comp positive means lag)
//	bit 15-8  CH2 relative to CH3 phase delay
//	bit 7-0   CH0 relative to CH1 phase delay
#define WRITE_PHASE			0x4E
#define READ_PHASE			0x4F

// Gain config register ========================================================
//	bit 23, 22, 21 CH5, bit 20 BOOST_CH5
//	bit 19 BOOST CH4, bit 18, 17, 16 CH4
//	bit 15, 14, 13 CH3, bit 12 BOOST_CH3
//	bit 11 BOOST CH2, bit 10,  9,  8 CH2
//	bit 7,  6,  5  CH1, bit 4  BOOST_CH1
//	bit 3  BOOST CH0, bit 2,  1,  0  CH0

// 	Channel Gain
//		111 (reserved gain = 1)
//		110 (reserved gain = 1)
//		101 gain = 32
//		100 gain = 16
//		011 gain = 8
//		010 gain = 4
//		001 gain = 2
//		000 gain = 1

//	BOOST
//		1 (channel current x2)
//		0 (channel current normal)
#define WRITE_GAIN			0x50
#define READ_GAIN				0x51

// Status/Communication register ===============================================
//	DEFAULT: 0x804000
//		bit 23-22 Address Loop Setting
//			11: Cycle through entire reg map
//			10: Loop through reg TYPES (default)
//					Channel 0 to 5, MOD/PHASE/GAIN/STAT/CONFIG
//			01: Loop through reg GROUPS
//    			Chn 0/1, Chn2/3, Chn4/5, MOD/PHASE/GAIN, STAT/CONFIG
//			00: Continue read single reg (not incremented)
//
//		bit 21: Write mode bit (internal use only)
//			1: Static addressing write mode
//			0: Incremental addressing write mode (default)
//
//		bit 20-15 WIDTH_CHn
//			1: 24 bit
//			0: 16 bit (default)
//
//		bit 14 DR_LTY (data ready latency control for DRA, DRB and DRC pins)
//			1: No latency conversion, data ready pulses after 3 DRCLK periods (default)
//			0: Unsettled data is available after every DRCLK period
//
//		bit 13 DR_HIZ: data ready pin inactive state control for DRA, DRB and DRC
//			1: Default state is a logic high when data is NOT ready
//			0: Default state is a high impedance when data is not ready (default)
//
//		bit 12 DR_LINK (data ready link control
//			1: Data ready link on, all channels linked and data ready pulses from
//				 the most lagging ADC are present on each DR pin
//			0: Data ready link off (default)
//
//		bit 11-10 DRC_MODE
//			11: Both data ready pulses from CH4 CH5 are output on DRC pin
//			10: Data ready pulses from CH5 are output on DRC data ready pulse from
//          CH4 not present
//			01: Data ready pulses from CH4 are output on DRC data ready pulse from
//					CH5 not present
//			00: Data ready pulses from lagging ADC channel are output on DRC
//
//		bit 9-8 DRB_MODE (CH3, CH2 see DRC_MODE)
//		bit 7-6 DRA_MODE (CH1, CH0 see DRC_MODE)
//		bit 5-0 DRSTATUS_CHn (Data Ready Status)
//			1: Data not ready (default)
//			0: Data ready
#define WRITE_STATUS		0x52
#define READ_STATUS			0x53

// Config register =============================================================
//	DEFAULT: 0x000FD0
//		bit 23-18: RESET_CHn
//			1: Reset mode for channel n ON
//			0: Reset mode for channel n off (default)
//
//		bit 17-12 SHUTDOWN_CHn
//			1: Shutdown mode for channel n on
//			0: Shutdown mode for channel n off (default)
//
//		bit 11-6 DITHER_CHn
//			1: Dithering channel n on (default)
//			0: Dithering channel n off
//
//		bit 5-4 OSR (over sampling ratio)
//			11: 256
//			10: 128
//			01: 64 (default)
//			00: 32
//
//		bit 3-2 PRESCALE
//			11: AMCLK = MCLK/8
//			10: AMCLK = MCLK/4
//			01: AMCLK = MCLK/2
//			00: AMCLK = MCLK (default)
//
//		bit 1 EXTVREF (internal reference shutdown control)
//			1: Internal Vref disabled
//			0: Internal Vref enabled (default)
//
//		bit 0 EXTCLK (clock mode)
//			1: CLOCK mode (internal osc disabled)
//			0: XT mode (crystal between OSC1/OSC2) (default)
#define WRITE_CONFIG		0x54
#define READ_CONFIG			0x55

#define OSR_32 					0x0
#define OSR_64          0x1
#define OSR_128					0x2
#define OSR_256					0x3

// --- Public Functions --------------------------------------------------------

/*-------------------------------------------------------------------------*//**
  The init_ADC() initialized the different hardware drivers related to the 
  MCP39x3 FPGA interface.

  @param interface_addr
    The base address of the interface based on the FPGA memory map. This value
    is usually a 32 bits HEX value (ie 0x6000 2000) with the 12 bits LSB 
    being reserved for the interface.

  @return
    none.

  */
void init_ADC(addr_t interface_addr);

/*-------------------------------------------------------------------------*//**
  The disable_ADC() function is used to shutdown the ADC. 

  @param 
    none.

  @return
    none.

  */
void disable_ADC();

/*-------------------------------------------------------------------------*//**
  The enable_ADC() function is used to enable the ADC following a shutdown. 

  @param 
    none.

  @return
    none.

  */
void enable_ADC();

/*-------------------------------------------------------------------------*//**
  The reset_ADC() function is used to fully reset the ADC. All configuration
  registers are reset to their default value.

  @param 
    none.

  @return
    none.

  */
void reset_ADC();

/*-------------------------------------------------------------------------*//**
  The read_ADC_channel() function is used to read the converted value from
  a given channel.

  @param cmd
    The Read command for the intended channel.

  @return uint32_t
    The value read from the channel 

  */
uint32_t read_ADC_channel(uint8_t cmd);

/*-------------------------------------------------------------------------*//**
  The read_ADC_config() function is used to read the configuration register
  value from the MCP.

  @param 
    none.

  @return uint32_t
    The content of the Config register (24 bits right justified) 

  */
uint32_t read_ADC_config();

/*-------------------------------------------------------------------------*//**
  The read_ADC_status() function is used to read the status register value
  from the MCP.

  @param 
    none.

  @return uint32_t
    The content of the Status register (24 bits right justified) 

  */
uint32_t read_ADC_status();


/*-------------------------------------------------------------------------*//**
  The set_Channels_24bits() function is used to set the ADC to provide 
  24 bits precision value from its channels.

  @param 
    none.

  @return uint8_t
    Success (1) or failure (0) of the command

  */
uint8_t set_Channels_24bits();

/*-------------------------------------------------------------------------*//**
  The set_Channels_16bits() function is used to set the ADC to provide 
  16 bits precision value from its channels.

  @param 
    none.

  @return uint8_t
    Success (1) or failure (0) of the command

  */
uint8_t set_Channels_16bits();

#endif /* MCP39x3_H_ */
